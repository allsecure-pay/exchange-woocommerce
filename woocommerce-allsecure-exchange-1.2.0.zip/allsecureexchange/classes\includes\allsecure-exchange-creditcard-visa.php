<?php

final class WC_AllsecureExchange_CreditCard_Visa extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_visa';

    public $method_title = 'Visa Credit Card';
}
