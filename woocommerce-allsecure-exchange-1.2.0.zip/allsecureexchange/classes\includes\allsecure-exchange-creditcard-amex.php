<?php

final class WC_AllsecureExchange_CreditCard_Amex extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_amex';

    public $method_title = 'Amex Credit Card';
}
