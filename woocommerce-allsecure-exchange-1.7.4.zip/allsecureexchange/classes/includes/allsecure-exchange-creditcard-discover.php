<?php

final class WC_AllsecureExchange_CreditCard_Discover extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_discover';

    public $method_title = 'Discover Credit Card';
}
