<?php

namespace AllsecureExchange\Client\CustomerProfile\PaymentData;

use AllsecureExchange\Client\Json\DataObject;

/**
 * Class PaymentData
 *
 * @package AllsecureExchange\Client\CustomerProfile\PaymentData
 */
abstract class PaymentData extends DataObject {

}
