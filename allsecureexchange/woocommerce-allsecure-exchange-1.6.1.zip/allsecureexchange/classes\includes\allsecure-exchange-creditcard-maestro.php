<?php

final class WC_AllsecureExchange_CreditCard_Maestro extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_maestro';

    public $method_title = 'Maestro Credit Card';
}
