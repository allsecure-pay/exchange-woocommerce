=== WooCommerce AllSecure Exchange Extension ===
Contributors: AllSecure Exchange
Tags: Credit Card, e-commerce, payment, checkout
Requires at least: 4.9
Tested up to: 5.2.3
Requires PHP: 7.1
Stable tag: 1.6.1
WC requires at least: 3.6.0
WC tested up to: 3.7.0

AllSecure Exchange WooCommerce Extension

== Description ==

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/allsecureexchange` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress

**Configuration**

1. Go to `WooCommerce` > `Settings` > `Payments` in your shop's admin area.
1. Click on `Set up` on a `AllSecure Exchange` payment method.
    1. Enter your API and payment method credentials.
    1. Click on `Save changes`.
    1. Go back to `Payments` overview.
1. Enable configured `AllSecure Exchange` payment methods.

The active payment methods will be provided to your customers during checkout.
