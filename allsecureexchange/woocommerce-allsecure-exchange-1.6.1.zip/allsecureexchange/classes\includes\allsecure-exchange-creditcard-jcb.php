<?php

final class WC_AllsecureExchange_CreditCard_Jcb extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_jcb';

    public $method_title = 'JCB Credit Card';
}
