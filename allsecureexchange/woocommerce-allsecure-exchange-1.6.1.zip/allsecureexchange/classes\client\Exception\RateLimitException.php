<?php

namespace AllsecureExchange\Client\Exception;

/**
 * Class RateLimitException
 *
 * @package AllsecureExchange\Client\Exception
 */
class RateLimitException extends \Exception {

}
