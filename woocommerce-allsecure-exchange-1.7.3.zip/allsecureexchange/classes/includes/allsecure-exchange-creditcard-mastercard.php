<?php

final class WC_AllsecureExchange_CreditCard_Mastercard extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_mastercard';

    public $method_title = 'Mastercard Credit Card';
}
