<?php

final class WC_AllsecureExchange_CreditCard_Diners extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_diners';

    public $method_title = 'Diners Credit Card';
}
