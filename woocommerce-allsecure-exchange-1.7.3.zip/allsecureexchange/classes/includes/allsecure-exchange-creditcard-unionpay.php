<?php

final class WC_AllsecureExchange_CreditCard_UnionPay extends WC_AllsecureExchange_CreditCard
{
    public $id = 'creditcard_unionpay';

    public $method_title = 'UnionPay Credit Card';
}
